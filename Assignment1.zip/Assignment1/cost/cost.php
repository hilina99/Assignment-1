
<html>
<head>
<title>TAX</title>
<link rel ="stylesheet" type=text/css href=str.css>
</head>
<body>


    
    

 
   
    <form method="POST"  action="">   
  
 
   
        


    <?php 

$page_title = 'Widget Cost Calculator';
include ('../includes/header.html');


function calculate_total ($qty, $cost, $tax = 5) {
	
	$total = ($qty * $cost);
	$taxrate = ($tax / 100); // Turns 5% into 05.
	$total += ($total * $taxrate); // Add the tax
	
	return number_format($total, 2);
	
} 
if (isset($_POST['submitted'])) {
	
	
	if ( is_numeric($_POST['quantity']) && is_numeric($_POST['price']) ) {
		
		
		echo '<h1>Total Cost</h1>';
		
		
		
		if (is_numeric($_POST['tax'])) {
			$sum = calculate_total ($_POST['quantity'], $_POST['price'], $_POST['tax']);
		} else {
			$sum = calculate_total ($_POST['quantity'], $_POST['price']);
		}
		
		
		echo '<p>The total cost of purchasing ' . $_POST['quantity'] . ' Widget(s) at birr' . number_format ($_POST['price'], 2) . ' each, with tax, is birr' . $sum . '.</p>';
			
	} else {
	echo '<h1>Error!</h1>
	<p class="error">Please enter a valid quantity and price.</p>';
	}
	
} 
?>

<h1>Cost Calculator</h1>

<form action="calculator4.php" method="post">

<p> <input type="text" name="quantity" size="5" maxlengh="5" value="<?php if(isset($_POST['quantity'])) echo $_POST['quantity']; ?>" placeholder="Quality"/></p>
<p><input type="text" name="price" size="5" maxlengh="10" value="<?php if(isset($_POST['price'])) echo $_POST['price']; ?>" placeholder="Price"/></p>

<p><input type="text" name="tax" size="5" maxlengh="5" value="<?php if(isset($_POST['tax'])) echo $_POST['tax']; ?>" placeholder="Tax(%)(Optional)"/></p>

<p><input type="submit" name="submit" value="Calculate" /></p>

<input type="hidden" name="submitted" value="TRUE" />

</form>


    </form> 
  
</body>
</html>


