# Assignment-1-COST CALCULATOR
->the application is structured into three logical components that interact with each other.
->Model component manages the system data and associated operations on that data. The View component defines and manages how the data is presented to the user. The Controller component manages user interaction 
->The model view controller pattern .
->used PHP for making the web application  
-> the application is to calculate widget cost 
->what is needed is a quality ,price and ta which is optional 