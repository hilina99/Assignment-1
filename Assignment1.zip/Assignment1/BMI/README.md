# Assignment-1-BODY MASS INDEX
->the application is structured into three logical components that interact with each other.
->The model view controller pattern .
->used PHP for making the web application  
-> the application is to calculate BMI(body mass index) 
->what is needed is a height and weight